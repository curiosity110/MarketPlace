-- AlterTable
ALTER TABLE "User"
ADD COLUMN "username" TEXT,
ADD COLUMN "company" TEXT,
ADD COLUMN "website" TEXT,
ADD COLUMN "bio" TEXT,
ADD COLUMN "address" TEXT;
