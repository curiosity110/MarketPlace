export function Separator() {
  return <hr className="border-border" />;
}
