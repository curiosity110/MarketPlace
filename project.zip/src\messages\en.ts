export const en = {
  appName: "MarketPlace MKD",
  nav: {
    home: "Home",
    browse: "Browse",
    categories: "Categories",
    sell: "Sell",
    dashboard: "Dashboard",
    admin: "Admin",
    login: "Login",
    register: "Register",
    logout: "Logout",
  },
};
