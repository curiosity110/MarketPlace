export async function updateSession() {
  return;
}
